import React, { useEffect, useState } from "react";
import axios from "axios";
import "./App.css";

function App() {
  const [books, setBooks] = useState([]);
  const [newBook, setNewBook] = useState({
    title: "",
    author: "",
    genre: "",
    publishedYear: "",
  });

  useEffect(() => {
    axios
      .get("http://localhost:5000/books")
      .then((res) => setBooks(res.data))
      .catch((err) => console.error(err));
  }, []);

  const addBook = () => {
    axios
      .post("http://localhost:5000/books", newBook)
      .then((res) => setBooks([...books, res.data]))
      .catch((err) => console.error(err));
  };

  const deleteBook = (id) => {
    axios
      .delete(`http://localhost:5000/books/${id}`)
      .then(() => setBooks(books.filter((book) => book._id !== id)))
      .catch((err) => console.error(err));
  };

  return (
    <div className="container">
      <h1 className="title">Library Management System</h1>
      <div className="form">
        <input
          placeholder="Title"
          onChange={(e) => setNewBook({ ...newBook, title: e.target.value })}
        />
        <input
          placeholder="Author"
          onChange={(e) => setNewBook({ ...newBook, author: e.target.value })}
        />
        <input
          placeholder="Genre"
          onChange={(e) => setNewBook({ ...newBook, genre: e.target.value })}
        />
        <input
          placeholder="Published Year"
          type="number"
          onChange={(e) =>
            setNewBook({ ...newBook, publishedYear: e.target.value })
          }
        />
        <button onClick={addBook}>Add Book</button>
      </div>
      <table className="book-table">
        <thead>
          <tr>
            <th>Title</th>
            <th>Author</th>
            <th>Genre</th>
            <th>Published Year</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {books.map((book) => (
            <tr key={book._id}>
              <td>{book.title}</td>
              <td>{book.author}</td>
              <td>{book.genre}</td>
              <td>{book.publishedYear}</td>
              <td>
                <button
                  className="delete-button"
                  onClick={() => deleteBook(book._id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default App;
