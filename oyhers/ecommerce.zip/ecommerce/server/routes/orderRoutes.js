import express from "express";
import {
  createOrder,
  getOrders,
  updateOrderStatus,
  deleteOrder,
} from "../controllers/orderController.js";

const router = express.Router();

router.post("/orders", createOrder);
router.get("/orders", getOrders);
router.put("/orders/:id", updateOrderStatus);
router.delete("/orders/:id", deleteOrder);

export default router;
